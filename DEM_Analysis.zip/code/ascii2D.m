clear all; clc; close all;

%% Specify the directory containing the DEM files
demDir = 'D:\daeijakdo\Bathymetry\ascii_proj'; % Replace with the actual path to your DEM files
cd(demDir);

% Get a list of all DEM files in the directory
demFiles = dir(fullfile(demDir, '*.txt')); % Assuming ASCII files have a .txt extension

% Initialize a cell array to hold the DEM data
demData = cell(length(demFiles), 1);

%% Loop through each file and load the data
for k = 1:length(demFiles)
    % Construct the full file name
    demFileName = fullfile(demDir, demFiles(k).name);
    
    % Open the file
    fileID = fopen(demFileName, 'r');
    
    % Read the header lines (6 lines)
    header = textscan(fileID, '%s %f', 6);
    
    % Extract header information
    ncols = header{2}(1);
    nrows = header{2}(2);
    xllcorner = header{2}(3);
    yllcorner = header{2}(4);
    cellsize = header{2}(5);
    
    % Read the remaining data as numeric
    dataArray = textscan(fileID, '%f', 'Delimiter', ' ', 'MultipleDelimsAsOne', 1);
    
    % Close the file
    fclose(fileID);
    
    % Reshape the data to match the DEM dimensions
    demData{k} = reshape(dataArray{1}, ncols, nrows)';
    
    % Display the file being processed
    disp(['Loaded ', demFiles(k).name]);
    
    % Calculate the x and y coordinates
    x = xllcorner + (0:ncols-1) * cellsize;
    y = yllcorner + (nrows-1:-1:0) * cellsize; % Reverse the y-coordinates
    
    % Set invalid data (NODATA) to NaN for proper colormap handling
    demData{k}(demData{k} == -9999) = NaN;
    
    % Optional: Display the DEM data as an image
    figure;
    h = plot(x, y, demData{k}); %for 3D use 'surf', 2D use 'plot'
    colormap([1 1 1; parula(256)]); % Add white for NaNs
    colorbar;
    title(['DEM: ', demFiles(k).name]);
    set(gca, 'YDir', 'normal'); % Ensure y-axis direction is correct
    xlabel('Easting (m)');
    ylabel('Northing (m)');
    
    % Restrict colorbar to data other than NODATA (-9999)
    validData = demData{k}(~isnan(demData{k})); % Extract valid data
    caxis([min(validData(:)) max(validData(:))]); % Set color axis limits
end
