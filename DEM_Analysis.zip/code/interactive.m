clear all;
clc;
close all;

%% Specify the directory containing the DEM files
demDir = 'D:\daeijakdo\Bathymetry\ascii_proj'; % Replace with the actual path to your DEM files
cd(demDir);

% Load DEM files
demFiles = dir(fullfile(demDir, '*.txt')); % Assuming ASCII files have a .txt extension

% Initialize a cell array to hold the DEM data
demData = cell(length(demFiles), 1);

% Load the shapefile
shapefilePath = 'D:\daeijakdo\Bathymetry\proj\obs_pt.shp';
S = shaperead(shapefilePath);

% Get the bounding box of the shapefile to use for zooming
x_min = min([S.X]);
x_max = max([S.X]);
y_min = min([S.Y]);
y_max = max([S.Y]);

% Add some allowance to the bounding box
buffer = 0.10; % 10% allowance
x_range = x_max - x_min;
y_range = y_max - y_min;
x_min = x_min - buffer * x_range;
x_max = x_max + buffer * x_range;
y_min = y_min - buffer * y_range;
y_max = y_max + buffer * y_range;

% Loop through each file and load the data
for k = 1:length(demFiles)
    demFileName = fullfile(demDir, demFiles(k).name);
    fileID = fopen(demFileName, 'r');
    header = textscan(fileID, '%s %f', 6);
    ncols = header{2}(1);
    nrows = header{2}(2);
    xllcorner = header{2}(3);
    yllcorner = header{2}(4);
    cellsize = header{2}(5);
    dataArray = textscan(fileID, '%f', 'Delimiter', ' ', 'MultipleDelimsAsOne', 1);
    fclose(fileID);
    demData{k} = reshape(dataArray{1}, ncols, nrows)';

    disp(['Loaded ', demFiles(k).name]);
    x = xllcorner + (0:ncols-1) * cellsize;
    y = yllcorner + (nrows-1:-1:0) * cellsize;

    mask = demData{k} == -9999;
    demData{k}(mask) = NaN;
    demData{k} = regionfill(demData{k}, mask);
    
    % Save the original data for contour plotting
    originalData = demData{k};
    
    % Increase resolution by interpolation
    [X, Y] = meshgrid(x, y);
    factor = 10; % Increase this factor to enhance resolution further
    xq = linspace(x(1), x(end), ncols * factor);
    yq = linspace(y(1), y(end), nrows * factor);
    [Xq, Yq] = meshgrid(xq, yq);
    
    % Interpolate valid data only
    validMask = ~mask;
    interpolatedData = griddata(X(validMask), Y(validMask), demData{k}(validMask), Xq, Yq, 'cubic');
    
    % Apply Gaussian smoothing only to the valid data region for visualization
    smoothedData = imgaussfilt(interpolatedData, 2); % Adjust the standard deviation as needed
    
    % Restore the original NoData values in smoothed data
    smoothedData(isnan(interpolatedData)) = -9999;
    
    in = inpolygon(Xq, Yq, [S.X], [S.Y]);
    boundedData = smoothedData;
    boundedData(~in) = NaN;

    % Save the bounded data in the cell array
    demData{k} = boundedData;
end

% Extract 2022 and 2019 data
demData2022 = demData{find(contains({demFiles.name}, '2022'))};
demData2019 = demData{find(contains({demFiles.name}, '2019'))};

% Ensure both datasets are aligned
assert(all(size(demData2022) == size(demData2019)), 'The 2022 and 2019 data must have the same dimensions');

% Calculate the difference
demDifference = demData2022 - demData2019;

% Plot the difference with a colormap
figure;
imshow(demDifference, [], 'XData', [xq(1) xq(end)], 'YData', [yq(1) yq(end)], 'InitialMagnification', 'fit');
axis on;
set(gca, 'YDir', 'normal');
flippedJet = flipud(jet(256));
customColormap = [1 1 1; flippedJet];
colormap(customColormap); % Use the custom flipped jet colormap
colorbar;
title('Difference between 2022 and 2019 DEM');
xlabel('Easting (m)');
ylabel('Northing (m)');

% Restrict the color axis to 0 to -30 meters
caxis([-30 0]);

% Set axis limits to the bounding box of the intersection area with allowance
xlim([x_min, x_max]);
ylim([y_min, y_max]);

% Add contour lines at 5-meter intervals
hold on;
contour(Xq, Yq, demDifference, 'LevelStep', 5, 'LineColor', 'k', 'ShowText', 'on');

for i = 1:length(S)
    plot(S(i).X, S(i).Y, 'b', 'LineWidth', 1.5);
end

% Interactive length calculation
disp('Click to select points for length measurement. Press Enter to finish.');
[x_points, y_points] = ginput;
plot(x_points, y_points, 'rx', 'LineWidth', 2, 'MarkerSize', 10);
for i = 1:length(x_points)-1
    plot([x_points(i), x_points(i+1)], [y_points(i), y_points(i+1)], 'r-', 'LineWidth', 1.5);
end

% Calculate and display the length
total_length = 0;
if length(x_points) > 1
    for i = 1:length(x_points)-1
        total_length = total_length + sqrt((x_points(i+1) - x_points(i))^2 + (y_points(i+1) - y_points(i))^2);
    end
    disp(['Total length: ', num2str(total_length), ' meters']);
else
    disp('Not enough points to calculate length.');
end

% Display length in the northwestern part of the plot
text(x_min + 0.05 * x_range, y_max - 0.05 * y_range, ['Length: ', num2str(total_length), ' meters'], 'Color', 'red', 'FontSize', 12, 'Interpreter', 'tex');

% Interactive perimeter, area, volume, and slope calculation
disp('Click to select points for perimeter, area, and volume calculation. Press Enter to finish.');
[x_poly, y_poly] = ginput;
plot(x_poly, y_poly, 'rx', 'LineWidth', 2, 'MarkerSize', 10);
for i = 1:length(x_poly)-1
    plot([x_poly(i), x_poly(i+1)], [y_poly(i), y_poly(i+1)], 'r-', 'LineWidth', 1.5);
end
plot([x_poly(end), x_poly(1)], [y_poly(end), y_poly(1)], 'r-', 'LineWidth', 1.5); % Close the polygon

% Calculate and display the perimeter
perimeter = 0;
if length(x_poly) > 1
    for i = 1:length(x_poly)-1
        perimeter = perimeter + sqrt((x_poly(i+1) - x_poly(i))^2 + (y_poly(i+1) - y_poly(i))^2);
    end
    perimeter = perimeter + sqrt((x_poly(end) - x_poly(1))^2 + (y_poly(end) - y_poly(1))^2); % Close the polygon
    disp(['Perimeter: ', num2str(perimeter), ' meters']);
else
    disp('Not enough points to calculate perimeter.');
end

% Calculate and display the area
area = 0;
if length(x_poly) > 2
    area = polyarea(x_poly, y_poly);
    disp(['Area: ', num2str(area), ' m^2']);
else
    disp('Not enough points to calculate area.');
end

% Calculate and display the volume
volume = 0;
if length(x_poly) > 2
    in_poly = inpolygon(Xq, Yq, x_poly, y_poly);
    volume = sum(demDifference(in_poly), 'omitnan') * cellsize * cellsize /(factor * factor);
    disp(['Volume: ', num2str(volume), ' m^3']);
else
    disp('Not enough points to calculate volume.');
end

% Display perimeter, area, volume, and slope in the northwestern part of the plot
text(x_min + 0.05 * x_range, y_max - 0.1 * y_range, ['Perimeter: ', num2str(perimeter), ' meters'], 'Color', 'red', 'FontSize', 12, 'Interpreter', 'tex');
text(x_min + 0.05 * x_range, y_max - 0.15 * y_range, ['Area: ', num2str(area), ' m^2'], 'Color', 'red', 'FontSize', 12, 'Interpreter', 'tex');
text(x_min + 0.05 * x_range, y_max - 0.2 * y_range, ['Volume: ', num2str(volume), ' m^3'], 'Color', 'red', 'FontSize', 12, 'Interpreter', 'tex');

hold off;
