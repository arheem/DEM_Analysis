clear all;
clc;
close all;

%% Specify the directory containing the DEM files
demDir = 'D:\daeijakdo\Bathymetry\ascii_proj'; % Replace with the actual path to your DEM files
cd(demDir);

% Load DEM files
demFiles = dir(fullfile(demDir, '*.txt')); % Assuming ASCII files have a .txt extension

% Initialize a cell array to hold the DEM data
demData = cell(length(demFiles), 1);

% Load the shapefile
shapefilePath = 'D:\daeijakdo\Bathymetry\proj\obs_pt.shp';
S = shaperead(shapefilePath);

% Get the bounding box of the shapefile to use for zooming
x_min = min([S.X]);
x_max = max([S.X]);
y_min = min([S.Y]);
y_max = max([S.Y]);

% Add some allowance to the bounding box
buffer = 0.10; % 10% allowance
x_range = x_max - x_min;
y_range = y_max - y_min;
x_min = x_min - buffer * x_range;
x_max = x_max + buffer * x_range;
y_min = y_min - buffer * y_range;
y_max = y_max + buffer * y_range;

% Define a common grid
commonX = linspace(x_min, x_max, 1000); % Adjust the number of points as needed
commonY = linspace(y_min, y_max, 1000); % Adjust the number of points as needed
[commonXq, commonYq] = meshgrid(commonX, commonY);

% Create a mask from the shapefile
inShape = inpolygon(commonXq, commonYq, [S.X], [S.Y]);

% Loop through each file and load the data
for k = 1:length(demFiles)
    demFileName = fullfile(demDir, demFiles(k).name);
    fileID = fopen(demFileName, 'r');
    header = textscan(fileID, '%s %f', 6);
    ncols = header{2}(1);
    nrows = header{2}(2);
    xllcorner = header{2}(3);
    yllcorner = header{2}(4);
    cellsize = header{2}(5);
    dataArray = textscan(fileID, '%f', 'Delimiter', ' ', 'MultipleDelimsAsOne', 1);
    fclose(fileID);
    demData{k} = reshape(dataArray{1}, ncols, nrows)';

    disp(['Loaded ', demFiles(k).name]);
    x = xllcorner + (0:ncols-1) * cellsize;
    y = yllcorner + (nrows-1:-1:0) * cellsize;

    mask = demData{k} == -9999;
    demData{k}(mask) = NaN;
    demData{k} = regionfill(demData{k}, mask);
    
    % Interpolate DEM data to the common grid
    [X, Y] = meshgrid(x, y);
    demData{k} = griddata(X, Y, demData{k}, commonXq, commonYq, 'cubic');
    
    % Apply the shapefile mask
    demData{k}(~inShape) = NaN;
end

% Extract 2020 and 2017 data
demData2020 = demData{find(contains({demFiles.name}, '2020'))};
demData2017 = demData{find(contains({demFiles.name}, '2017'))};

% Ensure both datasets are aligned
assert(all(size(demData2020) == size(demData2017)), 'The 2020 and 2017 data must have the same dimensions');

% Calculate the difference
demDifference = demData2020 - demData2017;

% Set the non-overlapping areas to NaN
nonOverlappingMask = isnan(demData2020) | isnan(demData2017);
demDifference(nonOverlappingMask) = NaN;

% Plot the difference with a colormap
figure;
imshow(demDifference, [], 'XData', [commonX(1) commonX(end)], 'YData', [commonY(1) commonY(end)], 'InitialMagnification', 'fit');
axis on;
set(gca, 'YDir', 'normal');
flippedJet = flipud(jet(256));
customColormap = [1 1 1; flippedJet];
colormap(customColormap); % Use the custom flipped jet colormap
colorbar;
title('Difference between 2020 and 2017 DEM');
xlabel('Easting (m)');
ylabel('Northing (m)');

% Restrict the color axis to 0 to -30 meters
caxis([-30 0]);

% Set axis limits to the bounding box of the intersection area with allowance
xlim([x_min, x_max]);
ylim([y_min, y_max]);

% Add contour lines at 5-meter intervals
hold on;
contour(commonXq, commonYq, demDifference, 'LevelStep', 1, 'LineColor', 'k', 'ShowText', 'on');

for i = 1:length(S)
    plot(S(i).X, S(i).Y, 'b', 'LineWidth', 1.5);
end

hold off;
