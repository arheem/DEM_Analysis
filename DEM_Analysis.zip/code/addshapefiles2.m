clear all;
clc;
close all;

%% Specify the directory containing the DEM files
tic
demDir = 'D:\daeijakdo\Bathymetry\ascii_proj'; % Replace with the actual path to your DEM files
cd(demDir);

% Get a list of all DEM files in the directory
demFiles = dir(fullfile(demDir, '*.txt')); % Assuming ASCII files have a .txt extension

% Initialize a cell array to hold the DEM data
demData = cell(length(demFiles), 1);

% Load the shapefiles (replace with the actual paths to your shapefiles)
shapefilePath1 = 'D:\daeijakdo\Bathymetry\proj\obs_pt.shp';
S1 = shaperead(shapefilePath1);

shapefilePath2 = 'D:\daeijakdo\Bathymetry\proj\shp1\pj_shp.shp';
S2 = shaperead(shapefilePath2);

% Get the bounding box of the shapefiles to use for zooming
bbox = [min([S1.X, S2.X]), min([S1.Y, S2.Y]); max([S1.X, S2.X]), max([S1.Y, S2.Y])];
toc

% Specify the directory to save the figures
saveDir = 'D:\daeijakdo\Bathymetry\figures';
if ~exist(saveDir, 'dir')
    mkdir(saveDir);
end

%% Loop through each file and load the data
tic
for k = 1:length(demFiles)
    % Construct the full file name
    demFileName = fullfile(demDir, demFiles(k).name);
    
    % Open the file
    fileID = fopen(demFileName, 'r');
    
    % Read the header lines (6 lines)
    header = textscan(fileID, '%s %f', 6);
    
    % Extract header information
    ncols = header{2}(1);
    nrows = header{2}(2);
    xllcorner = header{2}(3);
    yllcorner = header{2}(4);
    cellsize = header{2}(5);
    
    % Read the remaining data as numeric
    dataArray = textscan(fileID, '%f', 'Delimiter', ' ', 'MultipleDelimsAsOne', 1);
    
    % Close the file
    fclose(fileID);
    
    % Reshape the data to match the DEM dimensions
    demData{k} = reshape(dataArray{1}, ncols, nrows)';
    
    % Display the file being processed
    disp(['Loaded ', demFiles(k).name]);
    
    % Calculate the x and y coordinates
    x = xllcorner + (0:ncols-1) * cellsize;
    y = yllcorner + (nrows-1:-1:0) * cellsize; % Ensure y-coordinates are descending

    % Set invalid data (NODATA) to NaN for proper colormap handling
    mask = demData{k} == -9999;
    demData{k}(mask) = NaN;
    
    % Interpolate NaN values within the valid data region
    demData{k} = regionfill(demData{k}, mask);
    
    % Save the original data for contour plotting
    originalData = demData{k};
    
    % Increase resolution by interpolation
    [X, Y] = meshgrid(x, y);
    factor = 5; % Increase this factor to enhance resolution further
    xq = linspace(x(1), x(end), ncols * factor);
    yq = linspace(y(1), y(end), nrows * factor);
    [Xq, Yq] = meshgrid(xq, yq);
    
    % Interpolate valid data only
    validMask = ~mask;
    interpolatedData = griddata(X(validMask), Y(validMask), demData{k}(validMask), Xq, Yq, 'linear');
    
    % Apply Gaussian smoothing only to the valid data region for visualization
    smoothedData = imgaussfilt(interpolatedData, 0.5); % Adjust the standard deviation as needed
    
    % Restore the original NoData values in smoothed data
    smoothedData(isnan(interpolatedData)) = -9999;
    
    %% Extract area bounded by the shapefile
    in = inpolygon(Xq, Yq, [S1.X], [S1.Y]); % Logical mask of points inside polygon
    boundedData = smoothedData;
    boundedData(~in) = NaN; % Set points outside the polygon to NaN

    %% Determine the bounding box of the intersection
    intersectedX = Xq(in);
    intersectedY = Yq(in);
    if isempty(intersectedX) || isempty(intersectedY)
        warning('No intersection found between the DEM and the shapefile.');
        continue;
    end
    x_min = min(intersectedX);
    x_max = max(intersectedX);
    y_min = min(intersectedY);
    y_max = max(intersectedY);

    %% Add some allowance to the bounding box
    buffer = 0.10; % 10% allowance
    x_range = x_max - x_min;
    y_range = y_max - y_min;
    x_min = x_min - buffer * x_range;
    x_max = x_max + buffer * x_range;
    y_min = y_min - buffer * y_range;
    y_max = y_max + buffer * y_range;

    %% Plot bounded data with 10 m intervals
    contourInterval = 2;
    minValue = -70;
    maxValue = -20;
    contourLevels = minValue:contourInterval:maxValue;
    
    figure('Units', 'normalized', 'Position', [0.1, 0.1, 0.8, 0.8]);
    imagesc(xq, yq, boundedData);
    colormap([1 1 1; jet(256)]); 
    hcb = colorbar; % Create colorbar and get its handle;
    title([ demFiles(k).name], 'FontSize', 16, 'FontWeight', 'bold');
    set(gca, 'YDir', 'normal'); % Ensure y-axis direction is correct
    xlabel('Easting (m)', 'FontSize', 14, 'FontWeight', 'bold');
    ylabel('Northing (m)', 'FontSize', 14, 'FontWeight', 'bold');
    
    % Set axis limits to the bounding box of the intersection area with allowance
    xlim([x_min, x_max]);
    ylim([y_min, y_max]);
    
    % Restrict colorbar to -20 to -70 meters
    caxis([minValue, maxValue]);
    
    hold on;
    for i = 1:length(S1)
        plot(S1(i).X, S1(i).Y, 'b', 'LineWidth', 1.5);
    end
    for i = 1:length(S2)
        plot(S2(i).X, S2(i).Y, 'r', 'LineWidth', 1.5); % Different color for the second shapefile
    end
    
    % Calculate the centroid of the new shapefile
    [centroidX, centroidY] = calculateCentroid(S2);
    
    % Plot a red "X" at the centroid
    plot(centroidX, centroidY, 'r.', 'MarkerSize', 12, 'LineWidth', 2);
    
    % Add contour lines with 10 m intervals
    [C, h] = contour(Xq, Yq, boundedData, contourLevels, 'LineColor', 'black', 'LineWidth', 1);
    clabel(C, h, 'FontSize', 8, 'Color', 'black'); % Optionally label contour lines
    hold off;
    

    % Label the colorbar as "Depth" with specific font properties
    ylabel(hcb, 'Depth(m)', 'FontSize', 12, 'FontWeight', 'bold','Rotation',90);
    
    % Set ticks outside
    set(gca, 'TickDir', 'in');
    
    % Set the font size for the tick labels (coordinates)
    set(gca, 'FontSize', 9);
    
    % Center the plot
    set(gca, 'Box', 'on');

    % Set the figure properties to preserve the aspect ratio
    set(gcf, 'PaperPositionMode', 'auto');
    set(gca, 'DataAspectRatio', [1 1 1]);
     
    % Adjust paper size to match figure size
    fig = gcf;
    fig.PaperUnits = 'inches';
    fig.PaperPosition = [0 0 10 8]; % Adjust the size as needed
    fig.PaperSize = [10 8]; % Adjust the size as needed
    
    % Save the figure
    print(fullfile(saveDir, [demFiles(k).name(1:end-4)]), '-dpng', '-r300');
    close(gcf);
end
toc

