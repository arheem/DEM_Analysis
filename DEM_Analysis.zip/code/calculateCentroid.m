%% Function to calculate the centroid of a polygon shapefile
function [cx, cy] = calculateCentroid(S)
    % S is the shapefile structure array
    x = [S.X];
    y = [S.Y];
    % Remove NaNs (if any) that separate rings
    x = x(~isnan(x));
    y = y(~isnan(y));
    % Calculate centroid
    A = 0; % Partial area
    cx = 0; % Centroid x
    cy = 0; % Centroid y
    for i = 1:length(x)-1
        common = x(i) * y(i+1) - x(i+1) * y(i);
        A = A + common;
        cx = cx + (x(i) + x(i+1)) * common;
        cy = cy + (y(i) + y(i+1)) * common;
    end
    A = A / 2;
    cx = cx / (6 * A);
    cy = cy / (6 * A);
end