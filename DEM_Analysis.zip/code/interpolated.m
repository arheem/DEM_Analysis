clear all;
clc;
close all;

%% Specify the directory containing the DEM files
demDir = 'D:\daeijakdo\Bathymetry\ascii_proj'; % Replace with the actual path to your DEM files
cd(demDir);

% Get a list of all DEM files in the directory
demFiles = dir(fullfile(demDir, '*.txt')); % Assuming ASCII files have a .txt extension

% Initialize a cell array to hold the DEM data
demData = cell(length(demFiles), 1);

% Load the shapefile (replace with the actual path to your shapefile)
shapefilePath = 'D:\daeijakdo\Bathymetry\proj\obs_pt.shp';
S = shaperead(shapefilePath);

%% Loop through each file and load the data
for k = 1:length(demFiles)
    % Construct the full file name
    demFileName = fullfile(demDir, demFiles(k).name);
    
    % Open the file
    fileID = fopen(demFileName, 'r');
    
    % Read the header lines (6 lines)
    header = textscan(fileID, '%s %f', 6);
    
    % Extract header information
    ncols = header{2}(1);
    nrows = header{2}(2);
    xllcorner = header{2}(3);
    yllcorner = header{2}(4);
    cellsize = header{2}(5);
    
    % Read the remaining data as numeric
    dataArray = textscan(fileID, '%f', 'Delimiter', ' ', 'MultipleDelimsAsOne', 1);
    
    % Close the file
    fclose(fileID);
    
    % Reshape the data to match the DEM dimensions
    demData{k} = reshape(dataArray{1}, ncols, nrows)';
    
    % Display the file being processed
    disp(['Loaded ', demFiles(k).name]);
    
    % Calculate the x and y coordinates
    x = xllcorner + (0:ncols-1) * cellsize;
    y = yllcorner + (nrows-1:-1:0) * cellsize; % Ensure y-coordinates are descending

    % Set invalid data (NODATA) to NaN for proper colormap handling
    mask = demData{k} == -9999;
    demData{k}(mask) = NaN;
    
    % Interpolate NaN values within the valid data region
    demData{k} = regionfill(demData{k}, mask);
    
    % Save the original data for contour plotting
    originalData = demData{k};
    
    % Increase resolution by interpolation
    [X, Y] = meshgrid(x, y);
    factor = 5; % Increase this factor to enhance resolution further
    xq = linspace(x(1), x(end), ncols * factor);
    yq = linspace(y(1), y(end), nrows * factor);
    [Xq, Yq] = meshgrid(xq, yq);
    
    % Interpolate valid data only
    validMask = ~mask;
    interpolatedData = griddata(X(validMask), Y(validMask), demData{k}(validMask), Xq, Yq, 'linear');
    
    % Apply Gaussian smoothing only to the valid data region for visualization
    smoothedData = imgaussfilt(interpolatedData, 0.5); % Adjust the standard deviation as needed
    
    % Restore the original NoData values in smoothed data
    smoothedData(isnan(interpolatedData)) = -9999;
    
    %% 2D Visualization
    figure;
    imagesc(xq, yq, smoothedData);
    colormap([1 1 1; parula(256)]); % Add white for NaNs
    colorbar;
    title(['2D DEM: ', demFiles(k).name]);
    set(gca, 'YDir', 'normal'); % Ensure y-axis direction is correct
    xlabel('Easting (m)');
    ylabel('Northing (m)');
    
    % Overlay shapefile
    hold on;
    for i = 1:length(S)
        plot(S(i).X, S(i).Y, 'k');
    end
    
    % Restrict colorbar to data other than NODATA (-9999)
    validData = smoothedData(smoothedData ~= -9999); % Extract valid data
    caxis([min(validData(:)) max(validData(:))]); % Set color axis limits
    
    %% Add contour lines with an interval of 10 using original data
    contourInterval = 5;
    minValue = floor(min(originalData(:)) / contourInterval) * contourInterval;
    maxValue = ceil(max(originalData(:)) / contourInterval) * contourInterval;
    contourLevels = minValue:contourInterval:maxValue;
    
    % Mask the original data to exclude NoData values for contour plotting
    contourData = originalData;
    contourData(mask) = NaN;
    
    [C, h] = contour(X, Y, contourData, contourLevels, 'LineColor', 'black', 'LineWidth', 1);
    clabel(C, h, 'FontSize', 8, 'Color', 'black'); % Optionally label contour lines
    hold off;
end

%% Difference between 2022 and 2019 to define the pit area

